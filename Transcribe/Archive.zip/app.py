from flask import Flask, request, jsonify, render_template_string, send_file
import os
from datetime import datetime
import whisper
import yt_dlp as youtube_dl  # Using yt-dlp
import ffmpeg
import ssl
import certifi

# Set the default SSL context to use the certifi certificates
ssl._create_default_https_context = ssl.create_default_context(cafile=certifi.where())

app = Flask(__name__)

# Load the Whisper model
model = whisper.load_model("base")

# Directory to save the transcription text files
OUTPUT_DIR = "transcriptions"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Add a route for the home page with the form and progress bar
@app.route('/')
def home():
    return render_template_string('''
        <!DOCTYPE html>
        <html>
        <head>
            <title>Transcription App</title>
            <style>
                #progress-bar {
                    width: 100%;
                    background-color: #f3f3f3;
                    border: 1px solid #ccc;
                    margin-top: 20px;
                }
                #progress {
                    width: 0;
                    height: 20px;
                    background-color: #4caf50;
                }
            </style>
            <script>
                function startProgress() {
                    document.getElementById("progress").style.width = "0%";
                    document.getElementById("progress-bar").style.display = "block";
                    let progress = 0;
                    let interval = setInterval(() => {
                        if (progress >= 100) {
                            clearInterval(interval);
                        } else {
                            progress += 10;
                            document.getElementById("progress").style.width = progress + "%";
                        }
                    }, 500); // Adjust the interval as needed
                }
            </script>
        </head>
        <body>
            <h1>Welcome to the Transcription App</h1>
            <p>Use the form below to upload or provide a link for transcription.</p>
            <form id="transcription-form" method="POST" action="/transcribe" enctype="multipart/form-data" onsubmit="startProgress()">
                <label for="youtube-link">YouTube Video Link:</label>
                <input type="text" id="youtube-link" name="youtube_link" placeholder="Enter YouTube link"><br><br>
                
                <label for="file-upload">Or Upload Video/Audio File:</label>
                <input type="file" id="file-upload" name="file_upload" accept="audio/*,video/*"><br><br>
                
                <label>
                    <input type="checkbox" name="include_summary" value="true" checked> Include Summary
                </label><br>
                
                <label>
                    <input type="checkbox" name="include_outline" value="true" checked> Include Outline
                </label><br><br>
                
                <button type="submit">Transcribe</button>
            </form>
            <div id="progress-bar" style="display: none;">
                <div id="progress"></div>
            </div>
        </body>
        </html>
    ''')

@app.route('/transcribe', methods=['POST'])
def transcribe():
    youtube_link = request.form.get('youtube_link')
    file_upload = request.files.get('file_upload')
    include_summary = request.form.get('include_summary') == 'true'
    include_outline = request.form.get('include_outline') == 'true'

    transcription_text = ""
    duration = None

    if youtube_link:
        # Download and transcribe YouTube video
        try:
            with youtube_dl.YoutubeDL({'format': 'bestaudio'}) as ydl:
                result = ydl.extract_info(youtube_link, download=True)
                file_path = ydl.prepare_filename(result)
                duration = result.get('duration', None)
                transcription_text = transcribe_audio(file_path)
                os.remove(file_path)  # Cleanup downloaded file
        except Exception as e:
            return jsonify({"error": str(e)})

    if file_upload:
        # Save the uploaded file and transcribe
        file_path = os.path.join("uploads", file_upload.filename)
        file_upload.save(file_path)
        
        # Get the duration of the uploaded file
        try:
            probe = ffmpeg.probe(file_path)
            duration = float(probe['format']['duration'])
        except Exception as e:
            duration = None

        transcription_text = transcribe_audio(file_path)
        os.remove(file_path)  # Cleanup uploaded file

    # Build the final transcription with optional elements
    final_transcription = ""

    if include_summary:
        duration_str = f"{int(duration // 3600)}h {int((duration % 3600) // 60)}m {int(duration % 60)}s" if duration else "Unknown"
        summary = f"Source: {youtube_link or file_upload.filename}\n" \
                  f"App: Transcription App\n" \
                  f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n" \
                  f"Duration: {duration_str}\n" \
                  f"Letters Count: {len(transcription_text)}\n" \
                  f"Words Count: {len(transcription_text.split())}\n"
        final_transcription += summary + "\n"

    if include_outline:
        outline = "Outline:\n- Introduction\n- Key Points\n- Conclusion\n"  # Placeholder outline
        final_transcription += outline + "\n"

    final_transcription += transcription_text

    # Save the transcription to a text file
    output_file = os.path.join(OUTPUT_DIR, "transcription.txt")
    with open(output_file, "w") as f:
        f.write(final_transcription)

    # Provide a download link
    return send_file(output_file, as_attachment=True)

def transcribe_audio(file_path):
    """Function to transcribe audio using Whisper."""
    result = model.transcribe(file_path)
    return result['text']

if __name__ == '__main__':
    app.run(debug=True)